document.addEventListener('DOMContentLoaded', () => {
    const projects = document.querySelectorAll('.project');
    projects.forEach((project, index) => {
        project.style.opacity = 0;
        project.style.transform = 'translateY(20px)';
        setTimeout(() => {
            project.style.opacity = 1;
            project.style.transform = 'translateY(0)';
            project.style.transition = 'opacity 0.5s, transform 0.5s';
        }, index * 200);
    });
});